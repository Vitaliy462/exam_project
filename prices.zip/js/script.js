window.onload = function(){
    var sliderBlocks = document.getElementById("slider_blocks");
    for(let i = 0;i<sliderBlocks.childNodes.length;i++){
        console.log(sliderBlocks.childNodes[i]);
        if(sliderBlocks.childNodes[i].nodeName==="#text"){
            console.log("removed");
            sliderBlocks.removeChild(sliderBlocks.childNodes[i])
        }
    }

    var portfolioGalleries = document.querySelector('.portfolio_galleries');
    for (let i = 0; i < portfolioGalleries.childNodes.length; i++) {
        if(portfolioGalleries.childNodes[i].nodeName==="#text"){
            //console.log("removed");
            portfolioGalleries.removeChild(portfolioGalleries.childNodes[i])
        }
    }
    
    var photoOptions = document.querySelector('.photo_options');
    for (let i = 0; i < photoOptions.childNodes.length; i++) {
        if(photoOptions.childNodes[i].nodeName==="#text"){
            //console.log("removed");
            photoOptions.removeChild(photoOptions.childNodes[i])
        }
    }
    // for(let i = 2;i<=sliderBlocks.childNodes.length;i++){
    //     if(sliderBlocks.childNodes[i-1].dataset.number == i){
    //         console.log(sliderBlocks.childNodes[i-1]);
    //         sliderBlocks.childNodes[i-1].hidden = true;
    //     }
    // }
    for(let i = 1;i<=sliderBlocks.childNodes.length;i++){
        if(sliderBlocks.childNodes[i-1].dataset.number == i){
            console.log(sliderBlocks.childNodes[i-1]);
            sliderBlocks.childNodes[i-1].style.left += ((i-1)*1000) + 'px';
        }
    }

    for(let i = 1;i<portfolioGalleries.childNodes.length;i++){
        console.log(portfolioGalleries.childNodes[i]);
        portfolioGalleries.childNodes[i].style.display = 'none';   
    }
}


document.getElementById("contacts").onmouseover = function(event)
{
    if(event.target.className == "icon")
    {
        event.target.parentNode.style.width = 35 + 'px'
        event.target.parentNode.style.height = 35 + 'px'
    }
}

document.getElementById("contacts").onmouseout = function(event)
{
    if(event.target.className == "icon")
    {
        event.target.parentNode.style.width = 40 + 'px'
        event.target.parentNode.style.height = 40 + 'px'
    }
}

document.getElementById("slider1").onclick = function(event){
    // alert("sd");
    var sliderBlocks = document.getElementById("slider_blocks");
    let sliderImg;
    for(let i = 0;i<sliderBlocks.childNodes.length;i++){
        // if(sliderBlocks.childNodes[i].hidden==false){
        //     sliderImg = +sliderBlocks.childNodes[i].dataset.number;
        // }
        if(sliderBlocks.childNodes[i].classList.contains("selected")){
            sliderImg = +sliderBlocks.childNodes[i].dataset.number;
        }
    }
    console.log(event.target);
    if(event.target.id == "right"){
        if(sliderImg<3){
            // sliderBlocks.childNodes[sliderImg-1].hidden = true
            // sliderImg+=1;
            // sliderBlocks.childNodes[sliderImg-1].hidden = false
            // console.log(sliderImg);
            
            // sliderBlocks.childNodes[sliderImg-1].style.right += 1055 + 'px'
            // sliderImg+=1;
            for(let i = 0;i<sliderBlocks.childNodes.length;i++){
                if(parseInt(sliderBlocks.childNodes[2].style.left) == 0){
                    // alert("eys")
                    // for(let j = 1;j<=sliderBlocks.childNodes.length;j++){
                    //     if(sliderBlocks.childNodes[j-1].dataset.number == j){
                    //         console.log(sliderBlocks.childNodes[j-1]);
                    //         sliderBlocks.childNodes[j-1].style.left = ((j)*1000) + 'px';
                    //     }
                    // }
                }
                if(sliderBlocks.childNodes[i].style.display == 'none'){
                    sliderBlocks.childNodes[i].style.display = 'block'
                }
                
                sliderBlocks.childNodes[i].style.left = (parseInt(sliderBlocks.childNodes[i].style.left)-1000) + 'px';
                //sliderBlocks.childNodes[i].style.left = (parseInt(sliderBlocks.childNodes[i].style.left)-1000) + 'px';
                console.log(i);
            }
            for(let i = 0;i<sliderBlocks.childNodes.length;i++){
                if(parseInt(sliderBlocks.childNodes[i].style.left)<-1000){
                    sliderBlocks.childNodes[i].style.display = 'none'
                    returnPhotos(sliderBlocks.childNodes[i])
                }
            }
            
            // console.log(parseInt(sliderBlocks.childNodes[sliderImg-1].style.left));
            // sliderBlocks.childNodes[sliderImg-1].style.left = (parseInt(sliderBlocks.childNodes[sliderImg-1].style.left) -1055) + 'px'
            // console.log(sliderImg);
        }else{
            sliderBlocks.childNodes[sliderImg-1].hidden = true
            sliderImg=+sliderBlocks.firstElementChild.dataset.number;
            sliderBlocks.childNodes[sliderImg-1].hidden = false
        }
    }
    if(event.target.id == "left"){
        if(sliderImg>1){
            sliderBlocks.childNodes[sliderImg-1].hidden = true
            sliderImg-=1;
            sliderBlocks.childNodes[sliderImg-1].hidden = false
            console.log(sliderImg);
        }else{
            sliderBlocks.childNodes[sliderImg-1].hidden = true
            sliderImg=sliderBlocks.childNodes.length;
            sliderBlocks.childNodes[sliderImg-1].hidden = false
        }
    }
}

function returnPhotos(slide){
    // for(let i = 0;i<document.getElementById("slider_blocks").childNodes.length;i++){
        slide.style.left = ((+slide.dataset.number)*1000) + 'px'
        //slide.style.display = 'block'
    //}
}

document.querySelector(".photo_options").onclick = (e)=>{
    if(e.target.className == "photo_option"){
        let portfolio_galleries = document.querySelector('.portfolio_galleries')
        for (let i = 0; i <portfolio_galleries.childNodes.length; i++) {
            console.log("---" + window.getComputedStyle(portfolio_galleries.childNodes[i]).getPropertyValue("display"));
            if(window.getComputedStyle(portfolio_galleries.childNodes[i]).getPropertyValue("display") == "grid"){
                portfolio_galleries.childNodes[i].style.display = 'none'
            }   
        }
        for(let i = 0;i<document.querySelector(".photo_options").childNodes.length;i++){
            console.log(document.querySelector(".photo_options").childNodes[i]);
            if(document.querySelector(".photo_options").childNodes[i].classList.contains("selected")){
                document.querySelector(".photo_options").childNodes[i].classList.remove("selected")
            }
        }
        e.target.classList.add("selected")
        document.getElementById(e.target.dataset.gallery).style.display = 'grid'
    }
}


document.querySelector(".last_work_block").onmousemove = function(e){
    console.log(e);
    if(e.target.className == "photo" || e.target.className=="last_work_layer"){
        e.target.parentNode.childNodes[0].style.width = (e.clientX-415) + 'px'
    }
}
